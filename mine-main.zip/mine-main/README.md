Mis expectativas son mejorar mi creatividad, aprender más de una forma divertida, pedir ayuda cuando la necesite y prepararme para nuevos aprendizajes.
